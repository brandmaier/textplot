#' A package for creating character-based plots
#' 
#' General plotting functions are found in \code{\link{scatterText}} and \code{\link{barText}}.
#' 
"_PACKAGE"