textplot
========

R package for plots using characters only
